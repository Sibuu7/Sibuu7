[![MasterHead](https://repository-images.githubusercontent.com/588181932/e36ec678-7984-4cdd-8e4c-a3932772ff8e)](https://Sai1Ram.io)
<h1 align="center">Hi 👋, I'm Sai Ram Senapati</h1>
<h3 align="center">Mechanical Undergraduate at NIT Rourkela</h3>
<img align="right" alt="Coding" width="400" src="https://www.careerguide.com/career/wp-content/uploads/2020/03/full-stack-development.gif"/>

# 💫 About Me:
🔭 I’m currently working on **backend projects**<br>🌱 I’m currently learning **Next Js, TypeScript**<br>📫 How to reach me **sairamsenapati0022@gmail.com**<br>

# Follow me around the web:

<a href="https://www.linkedin.com/in/sai1ram/" target="_blank"><img src="https://img.shields.io/badge/-sai1ram-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/sai1ram/" alt="LinkedIn"></a>
<a href="https://instagram.com/__sai_ram_senapati?igshid=ZDdkNTZiNTM=" target="_blank"><img src="https://img.shields.io/badge/-sai_ram_senapati-e4405f?style=flat-square&logo=Instagram&logoColor=white&link=https://instagram.com/__sai_ram_senapati?igshid=ZDdkNTZiNTM=" alt="Instagram"></a>
<a href="https://twitter.com/SaiRam00223" target="_blank"><img src="https://img.shields.io/badge/SaiRam00223-000000?style=flat-square&logo=Twitter&logoColor=blue&link=https://twitter.com/SaiRam00223" alt="Twitter"></a>
<a href="https://sairamsenapati.netlify.app/" target="_blank"><img src="https://img.shields.io/badge/sairamsenapati.com-0D4B89?style=flat-square&logo=React&logoColor=white&link=https://sairamsenapati.netlify.app/" alt="Portfolio"></a>
<a href="mailto:sairamsenapati0022@gmail.com" target="_blank"><img src="https://img.shields.io/badge/-sairam-d14836?style=flat-square&logo=Gmail&logoColor=white&link=mailto:sairamsenapati0022@gmail.com" alt="Gmail"></a>




# 💻 Tech Stack:
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=plastic&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=plastic&logo=css3&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=plastic&logo=javascript&logoColor=%23F7DF1E) ![TailwindCSS](https://img.shields.io/badge/tailwindcss-%2338B2AC.svg?style=plastic&logo=tailwind-css&logoColor=white) ![Bootstrap](https://img.shields.io/badge/bootstrap-%23563D7C.svg?style=plastic&logo=bootstrap&logoColor=white) ![React](https://img.shields.io/badge/react-%2320232a.svg?style=plastic&logo=react&logoColor=%2361DAFB) ![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=plastic&logo=node.js&logoColor=white) ![Express.js](https://img.shields.io/badge/express.js-%23404d59.svg?style=plastic&logo=express&logoColor=%2361DAFB) ![PHP](https://img.shields.io/badge/php-%23777BB4.svg?style=plastic&logo=php&logoColor=white) ![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=plastic&logo=mongodb&logoColor=white) ![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=plastic&logo=mysql&logoColor=white) ![Postman](https://img.shields.io/badge/Postman-FF6C37?style=plastic&logo=postman&logoColor=white) ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=plastic&logo=java&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=plastic&logo=python&logoColor=ffdd54) ![Netlify](https://img.shields.io/badge/netlify-%23000000.svg?style=plastic&logo=netlify&logoColor=#00C7B7) ![Heroku](https://img.shields.io/badge/heroku-%23430098.svg?style=plastic&logo=heroku&logoColor=white)
# 📊 GitHub Stats:

GitHub Streaks | GitHub Stats | Top Languages |
| --- | --- | --- |
![Sai1Ram's GitHub Streaks](https://github-readme-streak-stats.herokuapp.com/?user=Sai1Ram&show_icons=true&title_color=f6c32c&icon_color=f6c32c&text_color=9f9f9f&bg_color=151515&count_private=true) | ![Sai1Ram's GitHub stats](https://github-readme-stats.vercel.app/api?username=Sai1Ram&show_icons=true&count_private=true) | ![Sai1Ram's top languages](https://github-readme-stats.vercel.app/api/top-langs/?username=Sai1Ram&show_icons=true&count_private=true&layout=compact) |
